// SupportAI: простой сервер на Node.js 18+ (без зависимостей)
const http = require("http"), fs = require("fs"), path = require("path");

// .env файлынан кілтті оқу
try {
  fs.readFileSync(path.join(__dirname, ".env"), "utf8").split("\n").forEach(l => {
    const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  });
} catch {}

const KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.MODEL || "claude-sonnet-5-5";
const PORT = process.env.PORT || 3000;

const SYSTEM = `Ты — ИИ-помощник службы поддержки интернет-магазина в Казахстане. Проанализируй обращение клиента.
Верни ТОЛЬКО JSON без пояснений и без markdown:
{"language":"ru|kk|other","category":"Доставка|Возврат/обмен|Качество товара|Оплата|Вопрос о товаре|Благодарность|Другое","sentiment":"negative|neutral|positive","priority":"high|medium|low","escalate":true|false,"summary":"одно предложение на русском","reply":"вежливый черновик ответа на языке клиента, 2-5 предложений, без выдуманных фактов (сроков, сумм), с просьбой уточнить данные заказа при необходимости"}
Правила: угроза жалобы/суда, повреждённый товар, возврат денег или явная срочность = priority high; escalate=true для high с претензией.`;

function send(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}

http.createServer((req, res) => {
  if (req.method === "GET" && (req.url === "/" || req.url === "/index.html")) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return res.end(fs.readFileSync(path.join(__dirname, "public", "index.html")));
  }
  if (req.method === "POST" && req.url === "/api/analyze") {
    let body = "";
    req.on("data", c => { body += c; if (body.length > 20000) req.destroy(); });
    req.on("end", async () => {
      try {
        if (!KEY) return send(res, 500, { error: "Нет ANTHROPIC_API_KEY в файле .env" });
        const text = String(JSON.parse(body).text || "").slice(0, 4000);
        const r = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: { "content-type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" },
          body: JSON.stringify({ model: MODEL, max_tokens: 800, system: SYSTEM,
            messages: [{ role: "user", content: "Обращение клиента:\n" + text }] })
        });
        const data = await r.json();
        if (!r.ok) return send(res, 502, { error: data.error?.message || "Ошибка API" });
        const raw = data.content.map(b => b.text || "").join("").replace(/```json|```/g, "").trim();
        send(res, 200, JSON.parse(raw));
      } catch (e) { send(res, 500, { error: String(e.message || e) }); }
    });
    return;
  }
  res.writeHead(404); res.end("Not found");
}).listen(PORT, () => console.log("Открой: http://localhost:" + PORT));
