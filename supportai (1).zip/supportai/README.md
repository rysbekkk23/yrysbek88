# SupportAI (локальный запуск)

1. Установи Node.js 18+ (https://nodejs.org).
2. Получи API-ключ: https://console.anthropic.com (раздел API Keys; нужен баланс).
3. Скопируй `.env.example` в файл `.env` и вставь ключ после `=`.
4. В папке проекта выполни:  node server.js
5. Открой в браузере: http://localhost:3000

Ключ хранится только на сервере (.env), в браузер он не попадает. Файл .env никому не отправляй.
